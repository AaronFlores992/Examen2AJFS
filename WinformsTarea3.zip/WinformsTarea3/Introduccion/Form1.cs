namespace Introduccion;

public partial class Form1 : Form
{
    Label? lblFigura;
    ComboBox? cmbFiguras;
    Label? lblCalculo;
    ComboBox? cmbCalculo;
    Label? lblAltura;
    TextBox? txtAltura;
    Label? lblBase;
    TextBox? txtBase;
    Label? lblLadoC;
    TextBox? txtLadoC;
    Button? btnCalcular;
    Label? lblResultado;
    TextBox? txtResultado;
    public Form1()
    {
        InitializeComponent();
        InicializarComponentes();
        cmbCalculo.SelectedItem = "Perímetro";
        cmbFiguras.SelectedItem = "Cuadrado";
    }
    private void InicializarComponentes()
    {
        this.Size = new Size(300, 350);
        //Etiqueta "Figura"
        lblFigura = new Label();
        lblFigura.Text = "Figura";
        lblFigura.AutoSize = true;
        lblFigura.Location = new Point(10, 10);
        //Combobox Figuras
        cmbFiguras = new ComboBox();
        cmbFiguras.Items.Add("Cuadrado");
        cmbFiguras.Items.Add("Rectángulo");
        cmbFiguras.Items.Add("Triángulo");
        cmbFiguras.Location = new Point(10, 40);
        cmbFiguras.SelectedValueChanged += new EventHandler(cmbFiguras_ValueChanged);
        //Etiqueta "Cálculo"
        lblCalculo = new Label();
        lblCalculo.Text = "Cálculo";
        lblCalculo.AutoSize = true;
        lblCalculo.Location = new Point(150, 10);
        //Combobox Cálculos
        cmbCalculo = new ComboBox();
        cmbCalculo.Items.Add("Perímetro");
        cmbCalculo.Items.Add("Área");
        cmbCalculo.Location = new Point(150, 40);
        cmbCalculo.SelectedValueChanged += new EventHandler(cmbCalculo_ValueChanged);
        //Etiqueta "Altura"
        lblAltura = new Label();
        lblAltura.Text = "Altura";
        lblAltura.AutoSize = true;
        lblAltura.Location = new Point(10, 80);
        lblAltura.Visible=false;
        //TextBox Altura
        txtAltura = new TextBox();
        txtAltura.Size = new Size(100, 20);
        txtAltura.Location = new Point(60, 75);
        txtAltura.Visible=false;
        //Etiqueta "Base"
        lblBase = new Label();
        lblBase.Text = "Base";
        lblBase.AutoSize = true;
        lblBase.Location = new Point(10, 120);
        lblBase.Visible=false;
        //TextBox Base
        txtBase = new TextBox();
        txtBase.Size = new Size(100, 20);
        txtBase.Location = new Point(60, 115);
        txtBase.Visible=false;

        //Etiqueta "Lado C"
        lblLadoC = new Label();
        lblLadoC.Text = "C";
        lblLadoC.AutoSize = true;
        lblLadoC.Location = new Point(10, 160);
        lblLadoC.Visible = false;
        //TextBox Lado C
        txtLadoC = new TextBox();
        txtLadoC.Size = new Size(100, 20);
        txtLadoC.Location = new Point(60, 155);
        txtLadoC.Visible = false;

        //Boton Calcular
        btnCalcular = new Button();
        btnCalcular.Text = "Calcular";
        btnCalcular.AutoSize = true;
        btnCalcular.Location = new Point(170, 200);
        btnCalcular.Click+= new EventHandler(btnCalcular_Click);
        //Etiqueta "Resultado"
        lblResultado = new Label();
        lblResultado.Text = "Resultado";
        lblResultado.AutoSize = true;
        lblResultado.Location = new Point(10, 280);
        //TextBox Resultado
        txtResultado = new TextBox();
        txtResultado.Size = new Size(100, 20);
        txtResultado.Location = new Point(70, 275);

        this.Controls.Add(lblFigura);
        this.Controls.Add(cmbFiguras);
        this.Controls.Add(lblCalculo);
        this.Controls.Add(cmbCalculo);
        this.Controls.Add(lblAltura);
        this.Controls.Add(txtAltura);
        this.Controls.Add(lblBase);
        this.Controls.Add(txtBase);
        this.Controls.Add(lblLadoC);
        this.Controls.Add(txtLadoC);
        this.Controls.Add(btnCalcular);
        this.Controls.Add(lblResultado);
        this.Controls.Add(txtResultado);

    }
    private void btnCalcular_Click(object sender, EventArgs e){
        string calculo= cmbCalculo.SelectedItem.ToString();
        string figura = cmbFiguras.SelectedItem.ToString();
        

        if (calculo == "Perímetro") {
            if (figura == "Cuadrado") {
                perimetroCuadrado();
            }
            if (figura == "Rectángulo")
            {
                perimetroRectangulo();
            }
            if (figura == "Triángulo")
            {
                perimetroTriangulo();
            }
        }
        if (calculo == "Área") {
            if (figura == "Cuadrado") {
                areaCuadradado();
            }
            if (figura == "Rectángulo")
            {
                areaRectangulo();
            }
            if (figura == "Triángulo")
            {
                areaTriangulo();   
            }
        }

        
        
    }
    //Calcula el perimetro del cuadradado.
    private void perimetroCuadrado() {
        int altura = 0;
        if (txtAltura.Text != "")
        {
            try
            {
                altura = Convert.ToInt32(txtAltura.Text);
            }
            catch (Exception) { }
            txtResultado.Text = (altura * 4).ToString();
        }
    }
    // Calcula el area del cuadradado.
    private void areaCuadradado() {
        int altura = 0;
        if (txtAltura.Text != "")
        {
            try
            {
                altura = Convert.ToInt32(txtAltura.Text);
            }
            catch (Exception) { }
            txtResultado.Text = (altura * altura).ToString();
        }
    }
    // Calcula perimetro de un rectangulo.
    private void perimetroRectangulo() {
        int altura = 0;
        int b = 0;
        if (txtAltura.Text != "" && txtBase.Text != "")
        {
            try
            {
                altura = Convert.ToInt32(txtAltura.Text);
                b = Convert.ToInt32(txtBase.Text);
            }
            catch (Exception) { }
            txtResultado.Text = (2 * (b + altura)).ToString();
        }
    }

    // Calcula area de un rectangulo.
    private void areaRectangulo()
    {
        int altura = 0;
        int b = 0;
        if (txtAltura.Text != "" && txtBase.Text != "")
        {
            try
            {
                altura = Convert.ToInt32(txtAltura.Text);
                b = Convert.ToInt32(txtBase.Text);
            }
            catch (Exception) { }
            txtResultado.Text = (b * altura).ToString();
        }
    }

    // Calcula perimetro de un triangulo.
    private void perimetroTriangulo()
    {
        int a = 0;
        int b = 0;
        int c = 0;
        if (txtAltura.Text != "" && txtBase.Text != "" && txtLadoC.Text != "")
        {
            try
            {
                a = Convert.ToInt32(txtAltura.Text);
                b = Convert.ToInt32(txtBase.Text);
                c = Convert.ToInt32(txtLadoC.Text);
            }
            catch (Exception) { }
            txtResultado.Text = (a+b+c).ToString();
        }
    }
    // Calcula area de un triangulo.
    private void areaTriangulo()
    {
        int altura = 0;
        int b = 0;
        
        if (txtAltura.Text != "" && txtBase.Text != "")
        {
            try
            {
                altura = Convert.ToInt32(txtAltura.Text);
                b = Convert.ToInt32(txtBase.Text);
                
            }
            catch (Exception) { }
            txtResultado.Text = ((b*altura)/2).ToString();
        }
    }
    private void cmbFiguras_ValueChanged(object sender, EventArgs e)
    {
        if (cmbFiguras.SelectedItem != null && cmbCalculo.SelectedItem != null)
        {
            if (cmbFiguras.SelectedItem.ToString() == "Cuadrado" && cmbCalculo.SelectedItem.ToString() == "Perímetro" || 
                cmbFiguras.SelectedItem.ToString() == "Cuadrado" && cmbCalculo.SelectedItem.ToString() == "Área")
            {
                
                lblAltura.Visible = true;
                txtAltura.Visible = true;
                lblBase.Visible = false;
                txtBase.Visible = false;
                lblLadoC.Visible = false;
                txtLadoC.Visible=false;

            }
            if (cmbFiguras.SelectedItem.ToString() == "Rectángulo" && cmbCalculo.SelectedItem.ToString() == "Perímetro" ||
                cmbFiguras.SelectedItem.ToString() == "Rectángulo" && cmbCalculo.SelectedItem.ToString() == "Área")
            {
                lblAltura.Visible = true;
                txtAltura.Visible = true;
                lblBase.Visible = true;
                txtBase.Visible = true;
                lblLadoC.Visible = false;
                txtLadoC.Visible = false;

            }
            if (cmbFiguras.SelectedItem.ToString() == "Triángulo" && cmbCalculo.SelectedItem.ToString() == "Perímetro")
            {
                lblAltura.Visible = true;
                txtAltura.Visible = true;
                lblBase.Visible = true;
                txtBase.Visible = true;
                lblLadoC.Visible = true;
                txtLadoC.Visible = true;

            }
            if (cmbFiguras.SelectedItem.ToString() == "Triángulo" && cmbCalculo.SelectedItem.ToString() == "Área")
            {
                lblAltura.Visible = true;
                txtAltura.Visible = true;
                lblBase.Visible = true;
                txtBase.Visible = true;
                lblLadoC.Visible = false;
                txtLadoC.Visible = false;

            }


        }

    }
    private void cmbCalculo_ValueChanged(object sender, EventArgs e)
    {
        if (cmbFiguras.SelectedItem != null && cmbCalculo.SelectedItem != null)
        {
            if (cmbFiguras.SelectedItem.ToString() == "Cuadrado" && cmbCalculo.SelectedItem.ToString() == "Perímetro" ||
                 cmbFiguras.SelectedItem.ToString() == "Cuadrado" && cmbCalculo.SelectedItem.ToString() == "Área")
            {

                lblAltura.Visible = true;
                txtAltura.Visible = true;
                lblBase.Visible = false;
                txtBase.Visible = false;
                lblLadoC.Visible = false;
                txtLadoC.Visible = false;

            }
            if (cmbFiguras.SelectedItem.ToString() == "Rectángulo" && cmbCalculo.SelectedItem.ToString() == "Perímetro" ||
                cmbFiguras.SelectedItem.ToString() == "Rectángulo" && cmbCalculo.SelectedItem.ToString() == "Área")
            {
                lblAltura.Visible = true;
                txtAltura.Visible = true;
                lblBase.Visible = true;
                txtBase.Visible = true;
                lblLadoC.Visible = false;
                txtLadoC.Visible = false;

            }
            if (cmbFiguras.SelectedItem.ToString() == "Triángulo" && cmbCalculo.SelectedItem.ToString() == "Perímetro")
            {
                lblAltura.Visible = true;
                txtAltura.Visible = true;
                lblBase.Visible = true;
                txtBase.Visible = true;
                lblLadoC.Visible = true;
                txtLadoC.Visible = true;

            }
            if (cmbFiguras.SelectedItem.ToString() == "Triángulo" && cmbCalculo.SelectedItem.ToString() == "Área")
            {
                lblAltura.Visible = true;
                txtAltura.Visible = true;
                lblBase.Visible = true;
                txtBase.Visible = true;
                lblLadoC.Visible = false;
                txtLadoC.Visible = false;

            }
        }
    }
}
