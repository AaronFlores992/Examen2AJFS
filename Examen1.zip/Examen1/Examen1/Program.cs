﻿using Examen1;
using Examen1.Modelos;

RuletaMetodos ruleta = new RuletaMetodos();

ruleta.inicializarDatos();
ruleta.showMenuPrincipal();
