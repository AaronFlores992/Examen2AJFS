﻿using Tarea2.Ejercicio1;
using Tarea2;
using Tarea2.Ejercicio2;

/*
GestorPeliculas gestor = new GestorPeliculas();
gestor.inicializarDatos();
gestor.showMenuPrincipal();*/

TiendaProductos tienda = new TiendaProductos();
tienda.inicializarDatos();
tienda.showMenuPrincipal();
            
